# -*- coding: utf-8 -*-
# qc_tagging_v2.py
# Version: 2.2 (Auto-batching + Single Line Progress)

import math
import time
import sys
import pymysql
from collections import defaultdict
from typing import List, Dict, Tuple, Any

# ---------------------------
# Parameters (tune as needed)
# ---------------------------
# [建議] 如果發現 Fail 率過高 (如 >90%)，請嘗試將 SNR_MIN 調低至 0.005 或 0.001
SNR_MIN = 0.015            
K_SW = 1.5
TILT_ABS_MAX = 2.0         # degrees
TILT_RSS_MAX = 2.5         # degrees
ELEV_MIN, ELEV_MAX = 10.0, 89.9 
AZ_DUP_TOL = 0.1           # degrees; near-duplicate azimuth tolerance
VR_ABS_MAX = 60.0          # m/s
MAD_K = 3.5
MIN_RAYS = 3               
MIN_SPAN_DEG = 120.0       
BIN_DEG = 10.0
MIN_NONEMPTY_BINS = 3      
VERT_THR = 2.0             # m/s difference vs neighbors' avg
NEIGHBOR_STEP = 1          # ±1 gate

# =========================
# Config (Matches doopler.sql)
# =========================
DB_HOST = "localhost"
DB_PORT = 3306
DB_USER = "shengic"
DB_PASSWORD = "sirirat"
DB_NAME = "doopler"

# ---------------
# Rule registry
# ---------------
RULE_REGISTRY = {}

def register(name):
    def deco(func):
        RULE_REGISTRY[name] = func
        return func
    return deco

# ---------- Utilities ----------
def safe_float(x, default=None):
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default

def median(values):
    vals = sorted(values)
    n = len(vals)
    if n == 0: return None
    mid = n // 2
    if n % 2 == 1: return vals[mid]
    return 0.5 * (vals[mid-1] + vals[mid])

def mad(values, med=None):
    if not values: return None
    if med is None: med = median(values)
    dev = [abs(v - med) for v in values]
    return median(dev)

def norm360(a):
    """Map degrees to [0,360). Collapse near-0 or near-360 to 0.0 using AZ_DUP_TOL."""
    if a is None: return None
    a = float(a) % 360.0
    if abs(a - 360.0) <= AZ_DUP_TOL or abs(a) <= AZ_DUP_TOL:
        return 0.0
    return a

def snap_azimuths_per_gate(rows_for_gate, tol=AZ_DUP_TOL):
    tmp = []
    for r in rows_for_gate:
        az = norm360(r.get('azimuth_deg'))
        tmp.append((r['range_gate_index'], r['ray_idx'], az))
    tmp.sort(key=lambda x: (9999.0 if x[2] is None else x[2]))

    seen = []
    canon_by_rowkey = {}
    dup_by_rowkey = {}
    for gi, ray_idx, az in tmp:
        key = (gi, ray_idx)
        if az is None:
            dup_by_rowkey[key] = True
            canon_by_rowkey[key] = None
            continue
        rep = None
        for c in seen:
            d = abs(az - c)
            d = min(d, 360.0 - d)
            if d <= tol:
                rep = c; break
        if rep is None:
            seen.append(az)
            canon_by_rowkey[key] = az
            dup_by_rowkey[key] = False
        else:
            canon_by_rowkey[key] = rep
            dup_by_rowkey[key] = True
    return canon_by_rowkey, dup_by_rowkey, sorted(seen)

def circular_span_deg(unique_az_deg):
    n = len(unique_az_deg)
    if n <= 1: return 0.0
    s = sorted(unique_az_deg)
    gaps = []
    for i in range(n):
        a = s[i]
        b = s[(i+1) % n]
        gaps.append((b - a) % 360.0)
    return 360.0 - max(gaps)

# ----------------------
# Rule Functions
# ----------------------
@register('check_nulls')
def check_nulls(row, ctx):
    for key in ('doppler_ms','azimuth_deg','elevation_deg'):
        if row.get(key) is None: return False, f"{key}=NULL"
    return True, None

@register('check_snr_min')
def check_snr_min(row, ctx):
    snr_plus1 = safe_float(row.get('intensity_snr_plus1'), default=1.0)
    snr = snr_plus1 - 1.0
    ok = snr >= SNR_MIN
    return ok, None if ok else f"snr={snr:.3f}<{SNR_MIN}"

@register('check_spectral_width_max')
def check_spectral_width_max(row, ctx):
    sw = safe_float(row.get('spectral_width_ms'), default=0.0)
    instr_sw = safe_float(ctx.get('instrument_spectral_width_ms'), default=0.0)
    thr = K_SW * (instr_sw if instr_sw > 0 else 1.0)
    ok = (sw <= thr)
    return ok, None if ok else f"sw={sw:.3f}>{thr:.3f}"

@register('check_pitch_roll_max')
def check_pitch_roll_max(row, ctx):
    pitch = abs(safe_float(row.get('pitch_deg'), 0.0))
    roll  = abs(safe_float(row.get('roll_deg'), 0.0))
    m = max(pitch, roll)
    ok = (m <= TILT_ABS_MAX)
    return ok, None if ok else f"tilt_abs={m:.2f}>{TILT_ABS_MAX:.2f}"

@register('check_attitude_vector')
def check_attitude_vector(row, ctx):
    pitch = safe_float(row.get('pitch_deg'), 0.0)
    roll  = safe_float(row.get('roll_deg'), 0.0)
    rss = math.hypot(pitch, roll)
    ok = (rss <= TILT_RSS_MAX)
    return ok, None if ok else f"tilt_rss={rss:.2f}>{TILT_RSS_MAX:.2f}"

@register('check_elevation_range')
def check_elevation_range(row, ctx):
    elev = safe_float(row.get('elevation_deg'))
    if elev is None: return False, "elev=NULL"
    ok = (ELEV_MIN <= elev <= ELEV_MAX)
    return ok, None if ok else f"elev={elev:.2f} not in [{ELEV_MIN},{ELEV_MAX}]"

@register('check_azimuth_duplicate_guard')
def check_azimuth_duplicate_guard(row, ctx):
    dup_map = ctx.get('az_dup_by_rowkey', {})
    key = (row['range_gate_index'], row['ray_idx'])
    is_dup = dup_map.get(key, False)
    return (not is_dup), None if not is_dup else f"dup_az_tol={AZ_DUP_TOL}deg"

@register('check_velocity_bounds')
def check_velocity_bounds(row, ctx):
    vr = safe_float(row.get('doppler_ms'))
    if vr is None: return False, "doppler=NULL"
    ok = (abs(vr) <= VR_ABS_MAX)
    return ok, None if ok else f"|vr|={abs(vr):.1f}>{VR_ABS_MAX:.1f}"

@register('check_gate_outlier_mad')
def check_gate_outlier_mad(row, ctx):
    key = (row['range_gate_index'], row['ray_idx'])
    bad = ctx['mad_fail_by_rowkey'].get(key, False)
    return (not bad), None if not bad else f"MAD_k>{MAD_K}"

@register('check_azimuth_coverage_gate')
def check_azimuth_coverage_gate(row, ctx):
    gi = row['range_gate_index']
    info = ctx['coverage_by_gate'].get(gi, {'count':0,'span':0.0})
    ok = (info['count'] >= MIN_RAYS and info['span'] >= MIN_SPAN_DEG)
    return ok, None if ok else f"coverage(cnt={info['count']},span={info['span']:.1f})"

@register('check_vertical_consistency')
def check_vertical_consistency(row, ctx):
    gi = row['range_gate_index']
    val = ctx['vert_metric_by_gate'].get(gi)
    ok = (val is None) or (val <= VERT_THR)
    return ok, None if ok else f"vert_diff={val:.2f}>{VERT_THR:.2f}"

@register('check_gate_uniform_bin_fill')
def check_gate_uniform_bin_fill(row, ctx):
    gi = row['range_gate_index']
    info = ctx['binfill_by_gate'].get(gi, {'nonempty':0})
    ok = (info['nonempty'] >= MIN_NONEMPTY_BINS)
    return ok, None if ok else f"bin_nonempty={info['nonempty']}<{MIN_NONEMPTY_BINS}"

# ----------------------
# Context Builders
# ----------------------
def precompute_gate_context(rows, header):
    by_gate = defaultdict(list)
    for r in rows:
        by_gate[r['range_gate_index']].append(r)

    canon_az_by_rowkey = {}
    unique_canon_by_gate = {}
    dup_by_rowkey = {}
    for gi, lst in by_gate.items():
        c, d, u = snap_azimuths_per_gate(lst, tol=AZ_DUP_TOL)
        canon_az_by_rowkey.update(c)
        dup_by_rowkey.update(d)
        unique_canon_by_gate[gi] = u

    mad_fail_by_rowkey = {}
    gate_medians = {}
    for gi, lst in by_gate.items():
        vrs = [safe_float(x.get('doppler_ms')) for x in lst if x.get('doppler_ms') is not None]
        vrs = [v for v in vrs if v is not None]
        med = median(vrs) if vrs else None
        gate_medians[gi] = med
        m = mad(vrs, med) if vrs else None
        if m is not None and m < 0.05: m = 0.05
        
        if med is not None and m is not None:
            for x in lst:
                vr = safe_float(x.get('doppler_ms'))
                if vr is None:
                    mad_fail_by_rowkey[(gi, x['ray_idx'])] = True
                elif (abs(vr - med) / (1.4826 * m)) > MAD_K:
                    mad_fail_by_rowkey[(gi, x['ray_idx'])] = True

    coverage_by_gate = {}
    binfill_by_gate = {}
    for gi, _lst in by_gate.items():
        uniq = unique_canon_by_gate.get(gi, [])
        coverage_by_gate[gi] = dict(count=len(uniq), span=(circular_span_deg(uniq) if uniq else 0.0))
        bins = set(int(a // BIN_DEG) for a in uniq) if uniq else set()
        binfill_by_gate[gi] = dict(nonempty=len(bins))

    vert_metric_by_gate = {}
    gis = sorted(by_gate.keys())
    for idx, gi in enumerate(gis):
        neighbors = []
        for step in range(1, NEIGHBOR_STEP+1):
            if idx - step >= 0: neighbors.append(gate_medians.get(gis[idx-step]))
            if idx + step < len(gis): neighbors.append(gate_medians.get(gis[idx+step]))
        neighbors = [v for v in neighbors if v is not None]
        cur = gate_medians.get(gi)
        vert_metric_by_gate[gi] = abs(cur - (sum(neighbors)/len(neighbors))) if (cur is not None and neighbors) else None

    return {
        'by_gate': by_gate, 'mad_fail_by_rowkey': mad_fail_by_rowkey,
        'coverage_by_gate': coverage_by_gate, 'binfill_by_gate': binfill_by_gate,
        'az_dup_by_rowkey': dup_by_rowkey, 'canon_az_by_rowkey': canon_az_by_rowkey,
        'vert_metric_by_gate': vert_metric_by_gate,
        'instrument_spectral_width_ms': header.get('instrument_spectral_width_ms')
    }

# ----------------------
# DB Helpers
# ----------------------
def get_conn():
    return pymysql.connect(host=DB_HOST, port=DB_PORT, user=DB_USER, password=DB_PASSWORD, db=DB_NAME, charset="utf8mb4", autocommit=False, cursorclass=pymysql.cursors.DictCursor)

def fetch_header(conn, header_id):
    with conn.cursor() as cur:
        cur.execute("SELECT * FROM wind_profile_header WHERE header_id=%s", (header_id,))
        return cur.fetchone()

def fetch_gate_rows(conn, header_id):
    sql = """
      SELECT id, header_id, range_gate_index, ray_idx, doppler_ms, intensity_snr_plus1, spectral_width_ms, azimuth_deg, elevation_deg, pitch_deg, roll_deg
      FROM wind_profile_gate WHERE header_id=%s
    """
    with conn.cursor() as cur:
        cur.execute(sql, (header_id,))
        return cur.fetchall()

def load_rules(conn):
    with conn.cursor() as cur:
        cur.execute("SELECT rule_id, def_name, COALESCE(description,'') AS description FROM vad_rule_qc WHERE is_active=1 ORDER BY COALESCE(rule_order,0), rule_id")
        rows = cur.fetchall()
    rules = []
    desc = {}
    for r in rows:
        func = RULE_REGISTRY.get(r['def_name'])
        if func:
            rules.append((int(r['rule_id']), r['def_name'], func))
            desc[int(r['rule_id'])] = r['description']
    return rules, desc

def update_qc_bulk(conn, updates):
    if not updates: return
    sql = "UPDATE wind_profile_gate SET qc_selected=%s, qc_failed_rules_csv=%s, qc_failed_rule_count=%s WHERE header_id=%s AND range_gate_index=%s AND ray_idx=%s"
    with conn.cursor() as cur:
        cur.executemany(sql, updates)

def fetch_pending_headers(conn, limit=1000):
    # Find headers that haven't been processed (assuming qc_failed_rule_count=0 and qc_selected=0 is default state)
    # Or check qc_updated_at via separate logic if strictly needed. 
    # For now, using logic: 'qc_selected' default is 0. 
    # NOTE: If you re-run QC, logic might need adjustment (e.g. check a separate process log table).
    sql = "SELECT DISTINCT header_id FROM wind_profile_gate WHERE qc_selected=0 AND qc_failed_rule_count=0 LIMIT %s"
    with conn.cursor() as cur:
        cur.execute(sql, (limit,))
        return [r['header_id'] for r in cur.fetchall()]

# ----------------------
# Main Logic (Single Line Mode)
# ----------------------
def run_qc_for_header(conn, header_id, rules, rule_desc, batch_cur, batch_total):
    try:
        rows = fetch_gate_rows(conn, header_id)
        if not rows:
            print(f"\r[WARN] Header {header_id} has no data".ljust(100), end="", flush=True)
            return

        header = fetch_header(conn, header_id)
        ctx = precompute_gate_context(rows, header)
        
        updates = []
        fail_stats = defaultdict(int)
        total = len(rows)

        for i, row in enumerate(rows, 1):
            failed_ids = []
            for rule_id, _def_name, func in rules:
                ok, _detail = func(row, ctx)
                if not ok: failed_ids.append(rule_id)
            
            failed_ids = sorted(set(failed_ids))
            selected = 0 if failed_ids else 1
            csv_val = ",".join(map(str, failed_ids)) if failed_ids else None
            
            if failed_ids: fail_stats['fail'] += 1
            else: fail_stats['pass'] += 1
            
            updates.append((selected, csv_val, len(failed_ids), row['header_id'], row['range_gate_index'], row['ray_idx']))

            # Single line refresh per 50 rows
            if i % 50 == 0 or i == total:
                msg = (f"[Batch {batch_cur}/{batch_total}] Header {header_id} | "
                       f"Rows {i}/{total} | "
                       f"Pass: {fail_stats['pass']} Fail: {fail_stats['fail']}")
                print(f"\r{msg.ljust(100)}", end="", flush=True)

        update_qc_bulk(conn, updates)
        conn.commit()

    except Exception as e:
        conn.rollback()
        print(f"\n[ERROR] Header {header_id} failed: {e}")
        # raise e # Uncomment if you want to stop on error

if __name__ == "__main__":
    conn = get_conn()
    try:
        print("=== Doopler QC Tagging V2.2 (Single Line Mode) ===")
        
        rules, rule_desc = load_rules(conn)
        if not rules:
            print("[CRITICAL] No active rules in vad_rule_qc table!")
        else:
            print(f"Loaded {len(rules)} rules.")
            print("Searching for pending headers...")
            
            pending = fetch_pending_headers(conn, limit=2000)
            
            if not pending:
                print("No pending headers found.")
            else:
                total_batches = len(pending)
                print(f"Found {total_batches} pending tasks. Starting...")
                
                for idx, hid in enumerate(pending, 1):
                    run_qc_for_header(conn, hid, rules, rule_desc, idx, total_batches)
                
                print("\n[DONE] All batches processed.")
                
    except KeyboardInterrupt:
        print("\n[STOP] User interrupted.")
    finally:
        conn.close()