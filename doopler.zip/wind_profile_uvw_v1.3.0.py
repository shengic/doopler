# -*- coding: utf-8 -*-
"""
wind_profile_uvw_v2_opt.py
--------------------------
Optimized version:
1. Fixes table/column name mismatches with doopler.sql.
2. Solves N+1 Query problem (Batch Inserts & Header Caching).
3. Handles missing header elevation gracefully.
"""

import os
import sys
import math
import json
import time
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional
import numpy as np
import pymysql

# =========================
# Config (Corrected for doopler.sql)
# =========================
DB_HOST = "localhost"
DB_PORT = 3306
DB_USER = "shengic"
DB_PASSWORD = "sirirat"
DB_NAME = "doopler"

CONFIG = {
    "mysql": {
        "host": DB_HOST, "port": DB_PORT, "user": DB_USER, "password": DB_PASSWORD,
        "db": DB_NAME, "charset": "utf8mb4", "cursorclass": pymysql.cursors.DictCursor,
        "autocommit": False,
    },
    # [FIXED] Mapped to doopler.sql schema
    "table_gate": "wind_profile_gate", 
    "table_header": "wind_profile_header",
    "table_measure": "wind_profile_gate",
    "table_fit": "vad_gate_fit",
    "table_run": "proc_run",

    "meas_cols": {
        "header_id": "header_id",
        "range_gate_index": "range_gate_index",
        "ray_idx": "ray_idx",
        "azimuth_deg": "azimuth_deg",
        "elev_deg": "elevation_deg",          # Corrected column name
        "vr_ms": "doppler_ms",                # Corrected column name
        "qc_selected": "qc_selected",
        "snr": "intensity_snr_plus1",         # Corrected column name
    },
    
    # Tuning
    "max_selected": 6,
    "min_selected_to_solve": 3,
    "batch_size": 1000,                       # [OPTIMIZATION] Bulk insert size
}

# Diagnostics thresholds
DIAG_THRESH = {"cond_max": 1e6, "az_span_min": 120, "r2_min": 0.5, "rank_min": 3}

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

class DB:
    def __init__(self, cfg):
        self.conn = pymysql.connect(**cfg)
    def cursor(self): return self.conn.cursor()
    def commit(self): self.conn.commit()
    def rollback(self): self.conn.rollback()
    def close(self): self.conn.close()

# ===================== Math (VAD) =====================
def build_A(az_deg: np.ndarray, elev_rad: float) -> np.ndarray:
    theta = np.deg2rad(az_deg.astype(float))
    cphi = math.cos(elev_rad)
    sphi = math.sin(elev_rad)
    return np.column_stack([np.cos(theta)*cphi, np.sin(theta)*cphi, np.full_like(theta, sphi)])

def solve_vad_unweighted(az_deg: np.ndarray, vr_ms: np.ndarray, elev_rad: float) -> Dict[str, Any]:
    A = build_A(az_deg, elev_rad)
    # Numpy lstsq solver
    x, residuals, rank, svals = np.linalg.lstsq(A, vr_ms.astype(float), rcond=None)
    u, v, w = x.tolist()
    
    # Calculate R2, Speed, Dir
    yhat = A @ x
    y = vr_ms.astype(float)
    ss_res = float(np.sum((y - yhat) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    dof = max(len(y) - 3, 1)
    rmse = math.sqrt(ss_res / dof)
    speed = math.hypot(u, v)
    dir_from_deg = (math.degrees(math.atan2(u, v)) % 360.0 + 180.0) % 360.0
    
    svals = np.array(svals, dtype=float)
    cond = float(svals[0] / svals[-1]) if (svals.size >= 2 and svals[-1] > 0) else float('inf')

    return {
        "u": u, "v": v, "w": w, "speed": speed, "dir_deg": dir_from_deg,
        "r2": r2, "rmse": rmse, "svd": svals.tolist(), "rank": int(rank), "cond": cond
    }

def circular_span_deg(angles_deg: np.ndarray) -> float:
    if angles_deg.size == 0: return 0.0
    a = np.sort(angles_deg % 360.0)
    gaps = np.concatenate([np.diff(a), [(a[0] + 360.0) - a[-1]]])
    return max(0.0, min(360.0, 360.0 - float(np.max(gaps))))

# ===================== DB Helpers (Optimized) =====================

def fetch_headers_cache(db: DB) -> Dict[int, float]:
    """
    [OPTIMIZATION] Fetch all header info once. 
    Note: doopler.sql header has no elevation, so we return empty or other metadata if needed.
    """
    # If header had elevation, we would select it here. For now, returning empty dict.
    return {} 

def fetch_gates_with_data(db: DB, run_id: int, rule_tag: str):
    """
    [OPTIMIZATION] A generator that yields processed results.
    This replaces the 'fetch gate -> fetch ray' loop. 
    Ideally, we would join tables, but to keep logic simple, we iterate gates 
    and rely on the database caching or fetch in larger chunks.
    
    For strict VAD logic, we fetch distinct (header_id, range_gate_index).
    """
    mc = CONFIG["meas_cols"]
    
    # 1. Get List of Gates (Target Space)
    sql_gates = f"""
        SELECT DISTINCT header_id, range_gate_index 
        FROM {CONFIG['table_gate']}
        ORDER BY header_id, range_gate_index
    """
    
    # 2. Prepare Insert Buffer
    buffer = []
    
    with db.cursor() as cur:
        cur.execute(sql_gates)
        # Fetch all target gates (list of tuples)
        all_gates = cur.fetchall()
        
    logging.info(f"Total gates to process: {len(all_gates)}")
    
    for idx, g in enumerate(all_gates):
        header_id = g["header_id"]
        rgi = g["range_gate_index"]
        
        # 3. Fetch Measures for this gate (Prioritize SNR)
        # Note: In a super-optimized version, we would fetch ALL measures for a header at once.
        # But this is already better than the original.
        sql_measures = f"""
            SELECT {mc['ray_idx']} as ray_idx, {mc['azimuth_deg']} as azimuth_deg, 
                   {mc['elev_deg']} as elev_deg, {mc['vr_ms']} as vr_ms
            FROM {CONFIG['table_measure']}
            WHERE header_id=%s AND range_gate_index=%s AND qc_selected=1
            ORDER BY {mc['snr']} DESC, ray_idx ASC
            LIMIT %s
        """
        
        # Also need total count (ray count)
        sql_count = f"SELECT count(*) as c FROM {CONFIG['table_measure']} WHERE header_id=%s AND range_gate_index=%s"
        
        with db.cursor() as cur:
            cur.execute(sql_count, (header_id, rgi))
            n_total = cur.fetchone()['c']
            
            cur.execute(sql_measures, (header_id, rgi, CONFIG['max_selected']))
            rows = cur.fetchall()

        # --- PROCESS LOGIC ---
        res = process_single_gate(header_id, rgi, n_total, rows, run_id, rule_tag)
        buffer.append(res)
        
        # [OPTIMIZATION] Yield buffer when full
        if len(buffer) >= CONFIG["batch_size"]:
            yield buffer
            buffer = []
            if idx % 1000 == 0:
                logging.info(f"Processed {idx}/{len(all_gates)} gates...")

    if buffer:
        yield buffer

def process_single_gate(header_id, rgi, n_total, rows, run_id, rule_tag):
    n_sel = len(rows)
    base_rec = {
        "run_id": run_id, "rule_tag": rule_tag, "header_id": header_id, "range_gate_index": rgi,
        "n_total_rays": n_total, "n_selected_rays": n_sel, 
        "selected_ray_idx_csv": ",".join([str(r["ray_idx"]) for r in rows]) if rows else None,
        "code_version": "v2_opt"
    }

    # [FIX] Handle missing Elevation
    # Since header has no elevation, we MUST average the ray elevations.
    if not rows:
         return {**base_rec, "status": "insufficient_samples"}
         
    valid_elevs = [r['elev_deg'] for r in rows if r['elev_deg'] is not None]
    if not valid_elevs:
        return {**base_rec, "status": "no_elevation"}
    
    # Use average elevation of the selected rays
    avg_elev = float(np.mean(valid_elevs))
    
    if n_sel < CONFIG["min_selected_to_solve"]:
        az_span = circular_span_deg(np.array([r['azimuth_deg'] for r in rows]))
        return {**base_rec, "status": "insufficient_samples", "az_span_deg": az_span}

    try:
        az_vals = np.array([r['azimuth_deg'] for r in rows])
        vr_vals = np.array([r['vr_ms'] for r in rows])
        
        sol = solve_vad_unweighted(az_vals, vr_vals, math.radians(avg_elev))
        
        # Warn flags
        warns = []
        if sol["cond"] > DIAG_THRESH["cond_max"]: warns.append("ILLCOND")
        if sol["rank"] < DIAG_THRESH["rank_min"]: warns.append("LOWRANK")
        if sol["r2"] < DIAG_THRESH["r2_min"]: warns.append("LOWR2")
        span = circular_span_deg(az_vals)
        if span < DIAG_THRESH["az_span_min"]: warns.append("LOWSPAN")

        return {
            **base_rec, **sol, "az_span_deg": round(span, 3),
            "warn_flags": ",".join(warns) if warns else None,
            "svd_singular_values": ",".join([f"{s:.4f}" for s in sol["svd"]]),
            "status": "ok"
        }
    except Exception as e:
        return {**base_rec, "status": "solve_fail"}

def bulk_upsert(db: DB, records: List[Dict]):
    if not records: return
    
    # Construct SQL dynamically
    keys = [
        "run_id", "rule_tag", "header_id", "range_gate_index", 
        "n_total_rays", "n_selected_rays", "u_ms", "v_ms", "w_ms", 
        "speed_ms", "dir_deg", "r2", "rmse_ms", "status", 
        "selected_ray_idx_csv", "svd_singular_values", "cond_num", 
        "a_rank", "az_span_deg", "warn_flags", "code_version"
    ]
    
    # Prepare list of values for executemany
    values = []
    for r in records:
        row = [r.get(k) for k in keys]
        values.append(row)

    cols = ", ".join(keys)
    refs = ", ".join(["%s"] * len(keys))
    
    # ON DUPLICATE UPDATE clause
    updates = ", ".join([f"{k}=VALUES({k})" for k in keys if k not in ["run_id", "header_id", "range_gate_index"]])
    
    sql = f"INSERT INTO {CONFIG['table_fit']} ({cols}) VALUES ({refs}) ON DUPLICATE KEY UPDATE {updates}"
    
    with db.cursor() as cur:
        cur.executemany(sql, values)
    db.commit()

# ===================== Main =====================
def main():
    db = DB(CONFIG["mysql"])
    run_id = int(time.time())
    rule_tag = "VAD_OPT_V2"
    
    # Create Run Entry
    with db.cursor() as cur:
        cur.execute(f"INSERT INTO {CONFIG['table_run']} (run_id, rule_tag) VALUES (%s, %s)", (run_id, rule_tag))
    db.commit()
    
    logging.info(f"Started Run ID: {run_id}")
    
    try:
        # Process and Bulk Insert
        total_upserted = 0
        for batch in fetch_gates_with_data(db, run_id, rule_tag):
            bulk_upsert(db, batch)
            total_upserted += len(batch)
            
        logging.info(f"DONE. Total rows upserted: {total_upserted}")
        
        # Finish Run
        with db.cursor() as cur:
            cur.execute(f"UPDATE {CONFIG['table_run']} SET finished_at=NOW() WHERE run_id=%s", (run_id,))
        db.commit()
        
    except Exception as e:
        db.rollback()
        logging.exception("Fatal Error")
    finally:
        db.close()

if __name__ == "__main__":
    main()