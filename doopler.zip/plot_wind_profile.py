# -*- coding: utf-8 -*-
"""
plot_wind_profile_v5_popup.py
-----------------------------
Fixes:
1. Forces Matplotlib to use 'TkAgg' backend to ensure the window pops up.
2. Includes all previous visual improvements (Bold, Colored Barbs).
"""

# [關鍵修正] 在匯入 pyplot 之前，強制設定後端為 TkAgg (互動視窗模式)
import matplotlib
try:
    matplotlib.use('TkAgg')
except Exception:
    print("Warning: TkAgg backend not available. Plot might not pop up.")

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.cm as cm
import matplotlib.colors as mcolors
import pandas as pd
import numpy as np
from sqlalchemy import create_engine

# =========================
# Config
# =========================
DB_CONNECTION_STR = "mysql+pymysql://shengic:sirirat@127.0.0.1:3306/doopler"

# Plot Settings
FIG_SIZE = (12, 6)
DPI = 150
MAX_HEIGHT_GATES = 60

# [視覺微調區]
BARB_INTERVAL = 8
BARB_GATE_INTERVAL = 2
BARB_LINEWIDTH = 1.2
BARB_LENGTH = 6.5
VMAX_SPEED = 25.0

def get_data():
    try:
        engine = create_engine(DB_CONNECTION_STR)
        sql = """
            SELECT 
                h.start_time,
                f.range_gate_index,
                COALESCE(h.range_gate_length_m, 30.0) as gate_len,
                f.u_ms,
                f.v_ms,
                f.speed_ms
            FROM vad_gate_fit f
            JOIN wind_profile_header h ON f.header_id = h.header_id
            WHERE f.status = 'ok'
              AND f.speed_ms IS NOT NULL
              AND f.speed_ms < 100
            ORDER BY h.start_time, f.range_gate_index
        """
        print("Reading data from MySQL...")
        with engine.connect() as conn:
            df = pd.read_sql(sql, conn)
        return df
    except Exception as e:
        print(f"Error reading data: {e}")
        return pd.DataFrame()

def plot_profile(df):
    if df.empty:
        print("No data found to plot.")
        return

    # 1. Preprocessing
    df['height_m'] = (df['range_gate_index'] + 0.5) * df['gate_len']
    df = df[df['range_gate_index'] <= MAX_HEIGHT_GATES]

    pivot_speed = df.pivot_table(index='height_m', columns='start_time', values='speed_ms')
    pivot_u = df.pivot_table(index='height_m', columns='start_time', values='u_ms')
    pivot_v = df.pivot_table(index='height_m', columns='start_time', values='v_ms')
    
    times = pivot_speed.columns
    heights = pivot_speed.index
    X, Y = np.meshgrid(mdates.date2num(times), heights)

    # 2. Plotting Setup
    # 這裡加入 block=False 避免視窗卡死，但通常在 main loop 最後 plt.show() 會處理
    fig, ax = plt.subplots(figsize=FIG_SIZE, dpi=DPI)
    
    cmap = plt.get_cmap('jet')
    norm = mcolors.Normalize(vmin=0, vmax=VMAX_SPEED)

    # 3. Subsampling
    skip_t = BARB_INTERVAL
    skip_h = BARB_GATE_INTERVAL
    
    X_sub = X[::skip_h, ::skip_t]
    Y_sub = Y[::skip_h, ::skip_t]
    u_sub = pivot_u.values[::skip_h, ::skip_t]
    v_sub = pivot_v.values[::skip_h, ::skip_t]
    speed_sub = pivot_speed.values[::skip_h, ::skip_t]

    mask = ~np.isnan(u_sub) & ~np.isnan(v_sub) & ~np.isnan(speed_sub)
    
    X_plot = X_sub[mask]
    Y_plot = Y_sub[mask]
    u_plot = u_sub[mask]
    v_plot = v_sub[mask]
    s_plot = speed_sub[mask]

    colors = cmap(norm(s_plot))

    # 4. Draw Bold Colored Barbs
    ax.barbs(X_plot, Y_plot, u_plot, v_plot, 
             color=colors,
             length=BARB_LENGTH,
             linewidth=BARB_LINEWIDTH,
             pivot='middle',
             sizes=dict(emptybarb=0.0))

    # 5. Add Colorbar
    sm = cm.ScalarMappable(cmap=cmap, norm=norm)
    sm.set_array([])
    cbar = plt.colorbar(sm, ax=ax, label='Horizontal Wind Speed (m/s)')

    # 6. Formatting
    ax.set_title(f'Lidar VAD Wind Profile (Popup Window)\nData Range: {times[0]} to {times[-1]}')
    ax.set_ylabel('Height AGL (m)')
    ax.set_xlabel('Time (UTC)')
    ax.set_ylim(0, heights.max() + 50)
    
    ax.grid(True, which='major', color='gray', linestyle='--', alpha=0.4)

    ax.xaxis_date()
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
    fig.autofmt_xdate()
    
    plt.tight_layout()
    
    output_file = "wind_profile_v5_popup.png"
    plt.savefig(output_file)
    print(f"Plot saved to: {output_file}")
    
    # [關鍵修正] 強制阻塞顯示視窗
    print("Opening plot window...")
    plt.show(block=True)

if __name__ == "__main__":
    df = get_data()
    plot_profile(df)